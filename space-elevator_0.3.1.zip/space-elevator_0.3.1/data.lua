-- Space Elevator Mod - Data Phase
-- Loads all prototype definitions

require("prototypes.entity")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.technology")
